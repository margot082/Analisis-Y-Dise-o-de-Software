/*
 * Esta aplicacion muestra el increible mensaje "¡Hola mundo!" por pantalla
 * 
 * @author Santiago Salas santiago.salas@estudiante.uam.es
 * @author Diego Nuñez diego.nunnezg@estudiante.uam.es
 */
public class HolaMundo 
{   
    /*
     * Punto de entrada de la aplicacion.
     * 
     * Este metodo imprime el increible mensaje "¡Hola mundo!" por pantalla
     * @param args Los argumentos de la línea de comando
     */
    public static void main(String[] args)
    {
        System.out.println("¡Hola mundo!"); // muestra el string por stdout
    }
}
